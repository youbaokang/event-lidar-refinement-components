"""Selected original algorithm functions, copied verbatim.
Only imports and module packaging are added; see SOURCE_MANIFEST.json.
"""
from __future__ import annotations

import cv2
import numpy as np
from scipy.spatial import cKDTree
from . import structure_geometry as base


def skeletonize_binary(mask: np.ndarray) -> np.ndarray:
    binary = np.where(mask > 0, 255, 0).astype(np.uint8)
    skel = np.zeros_like(binary)
    element = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    while cv2.countNonZero(binary) > 0:
        eroded = cv2.erode(binary, element)
        opened = cv2.dilate(eroded, element)
        residue = cv2.subtract(binary, opened)
        skel = cv2.bitwise_or(skel, residue)
        binary = eroded
    return skel


def make_thin_target(mask: np.ndarray) -> np.ndarray:
    mask_u8 = np.where(mask > 0, 255, 0).astype(np.uint8)
    mask_u8 = cv2.morphologyEx(mask_u8, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    thin = skeletonize_binary(mask_u8)
    thin = cv2.dilate(thin, cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3)))
    return np.where(thin > 0, 255, 0).astype(np.uint8)


def ground_skeletonize(points: np.ndarray, cell: float, max_points: int, rng: np.random.Generator) -> np.ndarray:
    if len(points) < 30:
        return points.copy()
    xy = points[:, :2]
    min_xy = xy.min(axis=0) - cell
    ij = np.floor((xy - min_xy) / cell).astype(np.int32)
    shape = ij.max(axis=0) + 3
    if np.any(shape <= 0) or int(shape[0]) * int(shape[1]) > 2_500_000:
        return base.voxel_downsample(points, None, voxel=0.35, max_points=max_points, rng=rng)[0]
    grid = np.zeros((int(shape[1]), int(shape[0])), dtype=np.uint8)
    grid[ij[:, 1], ij[:, 0]] = 255
    grid = cv2.morphologyEx(grid, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    skel = skeletonize_binary(grid)
    ys, xs = np.nonzero(skel)
    if len(xs) == 0:
        return base.voxel_downsample(points, None, voxel=0.35, max_points=max_points, rng=rng)[0]
    skel_xy = min_xy + np.column_stack([(xs + 0.5) * cell, (ys + 0.5) * cell])
    tree = cKDTree(xy)
    _, nearest = tree.query(skel_xy, k=1)
    unique_nearest = np.unique(nearest)
    skel_pts = points[unique_nearest]
    if len(skel_pts) > max_points:
        skel_pts = skel_pts[rng.choice(len(skel_pts), max_points, replace=False)]
    return skel_pts

