"""Selected original algorithm functions, copied verbatim.
Only imports and module packaging are added; see SOURCE_MANIFEST.json.
"""
from __future__ import annotations

import cv2
import numpy as np
from scipy import ndimage


def make_dist_map(mask: np.ndarray) -> np.ndarray:
    inv = np.where(mask > 0, 0, 255).astype(np.uint8)
    return cv2.distanceTransform(inv, cv2.DIST_L2, 5).astype(np.float32)


def camera_center(R: np.ndarray, t: np.ndarray) -> np.ndarray:
    return -R.T @ t


def voxel_downsample(points: np.ndarray, intensity: np.ndarray | None, voxel: float, max_points: int, rng: np.random.Generator):
    if len(points) == 0:
        return points, intensity if intensity is not None else None
    keys = np.floor(points / voxel).astype(np.int64)
    _, first = np.unique(keys, axis=0, return_index=True)
    pts = points[first]
    inten = intensity[first] if intensity is not None else None
    if len(pts) > max_points:
        pick = rng.choice(len(pts), max_points, replace=False)
        pts = pts[pick]
        if inten is not None:
            inten = inten[pick]
    return pts, inten


def split_poles_by_xy(points: np.ndarray, cell_size: float = 0.55) -> list[np.ndarray]:
    if len(points) == 0:
        return []
    keys = np.floor(points[:, :2] / cell_size).astype(np.int64)
    unique, inverse = np.unique(keys, axis=0, return_inverse=True)
    shifted = unique - unique.min(axis=0)
    shape = tuple((shifted.max(axis=0) + 1).astype(int))
    grid = np.zeros(shape, dtype=bool)
    grid[shifted[:, 0], shifted[:, 1]] = True
    labels, n_labels = ndimage.label(grid, structure=np.ones((3, 3), dtype=bool))
    unique_labels = labels[shifted[:, 0], shifted[:, 1]]
    point_labels = unique_labels[inverse]
    groups: list[np.ndarray] = []
    for label in range(1, n_labels + 1):
        group = points[point_labels == label]
        if len(group) < 18:
            continue
        p05 = np.percentile(group, 5, axis=0)
        p95 = np.percentile(group, 95, axis=0)
        extent = p95 - p05
        if extent[2] >= 0.45 and max(extent[0], extent[1]) <= 3.0:
            groups.append(group)
    groups.sort(key=lambda g: (np.percentile(g[:, 2], 95) - np.percentile(g[:, 2], 5)) * np.sqrt(len(g)), reverse=True)
    return groups


def skeletonize_pole_group(points: np.ndarray, step: float = 0.22) -> np.ndarray:
    if len(points) < 8:
        return points
    z_min, z_max = np.percentile(points[:, 2], [3, 97])
    out: list[np.ndarray] = []
    z = z_min
    while z <= z_max:
        sl = points[(points[:, 2] >= z) & (points[:, 2] < z + step)]
        if len(sl) >= 3:
            out.append(np.median(sl, axis=0))
        z += step
    if not out:
        return np.median(points, axis=0, keepdims=True)
    return np.asarray(out, dtype=np.float64)

