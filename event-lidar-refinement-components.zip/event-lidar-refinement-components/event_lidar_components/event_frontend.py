"""Selected original algorithm functions, copied verbatim.
Only imports and module packaging are added; see SOURCE_MANIFEST.json.
"""
from __future__ import annotations

import cv2
import numpy as np


def accumulate_events(width, height, x, y):
    image = np.zeros((height, width), dtype=np.float32)
    np.add.at(image, (y, x), 1.0)
    return image


def density_filter(activity, kernel_size=3, min_support=2):
    active = (activity > 0).astype(np.float32)
    kernel = np.ones((kernel_size, kernel_size), dtype=np.float32)
    support = cv2.filter2D(active, -1, kernel, borderType=cv2.BORDER_CONSTANT)
    keep = support >= float(min_support)
    return activity * keep


def normalize_activity(activity):
    normalized = np.log1p(activity)
    normalized = cv2.GaussianBlur(normalized, (0, 0), sigmaX=1.2, sigmaY=1.2)
    if np.max(normalized) <= 0:
        return np.zeros_like(normalized, dtype=np.uint8)
    normalized = cv2.normalize(normalized, None, 0, 255, cv2.NORM_MINMAX)
    return normalized.astype(np.uint8)


def filter_components(binary, min_area=40):
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    filtered = np.zeros_like(binary)

    for label in range(1, num_labels):
        x, y, w, h, area = stats[label]
        if area < min_area:
            continue

        aspect = max(w / max(h, 1), h / max(w, 1))
        if area >= 160 or aspect >= 2.0:
            filtered[labels == label] = 255

    return filtered


def orientation_aware_mask(gray):
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    closed = cv2.morphologyEx(
        binary,
        cv2.MORPH_CLOSE,
        cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)),
        iterations=1,
    )

    vertical = cv2.morphologyEx(
        closed,
        cv2.MORPH_OPEN,
        cv2.getStructuringElement(cv2.MORPH_RECT, (3, 17)),
        iterations=1,
    )
    horizontal = cv2.morphologyEx(
        closed,
        cv2.MORPH_OPEN,
        cv2.getStructuringElement(cv2.MORPH_RECT, (19, 3)),
        iterations=1,
    )

    merged = cv2.bitwise_or(vertical, horizontal)
    filtered = filter_components(merged)
    return binary, vertical, horizontal, filtered

