# Event LiDAR Refinement Components

Selected source components for event-image structural targets and LiDAR skeleton geometry. The release contains 13 existing functions, with their function bodies and default arguments retained unchanged. Imports and module organization make the selected functions usable without the original laboratory project folders.

This is a partial component release. It does not include the complete extrinsic optimizer, the three-pass calibration runner, reference calibrations, experiment drivers, or paper-result reproduction scripts.

中文说明见 [README_zh.md](README_zh.md).

## Contents

| Module | Functions |
| --- | --- |
| `event_lidar_components/event_frontend.py` | `accumulate_events`, `density_filter`, `normalize_activity`, `filter_components`, `orientation_aware_mask` |
| `event_lidar_components/structure_geometry.py` | `make_dist_map`, `camera_center`, `voxel_downsample`, `split_poles_by_xy`, `skeletonize_pole_group` |
| `event_lidar_components/target_fields.py` | `skeletonize_binary`, `make_thin_target`, `ground_skeletonize` |

The function manifest records source identities and hashes for the preserved functions. No third-party library source is bundled.

## Installation

Use Python 3.10 or newer and install NumPy, OpenCV, and SciPy from `requirements.txt`. Work from the repository root, the directory containing this README and the `event_lidar_components` folder. The package can be imported directly there; no editable installation is required.

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python your_program.py
```

Linux or macOS:

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python your_program.py
```

These are installation and usage instructions. No algorithm execution, new experiment, or fresh dependency installation was performed while preparing this release.

## Input conventions

- Event inputs are one-dimensional integer arrays `x` and `y` of equal length. Coordinates must be inside the supplied image width and height, with zero-based indexing. The caller selects the time window and supplies its event coordinates. Timestamp parsing, polarity policies, automatic window selection, and sensor synchronization are outside this component release.
- Binary masks are two-dimensional arrays. Positive pixels denote target structures; zero denotes background. `orientation_aware_mask` expects a grayscale `uint8` image and returns four `uint8` masks: thresholded binary, vertical response, horizontal response, and filtered merged response.
- Point inputs should be finite floating-point arrays of shape `(N, 3)`. The point-cloud functions assume metric coordinates, with `x` and `y` horizontal and `z` vertical. `split_poles_by_xy` expects pole candidates already selected from the scene; it is not a complete raw-cloud segmentation pipeline.
- `camera_center(R, t)` accepts a caller-supplied `(3, 3)` rotation and `(3,)` translation for the transform `p_camera = R @ p_lidar + t`. It returns the camera center in LiDAR coordinates as `-R.T @ t`.

## Example using your own input arrays

Create `your_program.py` in the repository root and adapt the following snippet. The `user_inputs.npz` file must be supplied by the caller; no such file or other dataset is included in this release.

```python
import numpy as np

from event_lidar_components.event_frontend import (
    accumulate_events,
    density_filter,
    normalize_activity,
    orientation_aware_mask,
)
from event_lidar_components.structure_geometry import (
    make_dist_map,
    split_poles_by_xy,
    skeletonize_pole_group,
)
from event_lidar_components.target_fields import make_thin_target

with np.load("user_inputs.npz", allow_pickle=False) as data:
    width = int(data["width"].item())
    height = int(data["height"].item())
    x = np.asarray(data["x"], dtype=np.int64)
    y = np.asarray(data["y"], dtype=np.int64)
    pole_points = np.asarray(data["pole_points"], dtype=np.float64)

activity = accumulate_events(width, height, x, y)
gray = normalize_activity(density_filter(activity))
binary, vertical, horizontal, target = orientation_aware_mask(gray)
thin_target = make_thin_target(target)
mask_distance_px = make_dist_map(target)
thin_distance_px = make_dist_map(thin_target)

pole_groups = split_poles_by_xy(pole_points, cell_size=0.55)
pole_skeletons = [
    skeletonize_pole_group(group, step=0.22)
    for group in pole_groups
]
```

`mask_distance_px` and `thin_distance_px` are image-domain distances, not extrinsic rotation or translation errors. The example constructs target fields and skeletons; it does not estimate a pose.

## Other component calls

```python
from event_lidar_components.structure_geometry import voxel_downsample
from event_lidar_components.target_fields import ground_skeletonize

# points and ground_points are caller-supplied (N, 3) arrays.
# intensity is an optional caller-supplied (N,) array, or None.
# rng is a caller-supplied numpy.random.Generator.
sampled_points, sampled_intensity = voxel_downsample(
    points, intensity, voxel=voxel_size_m,
    max_points=point_budget, rng=rng,
)
ground_skeleton = ground_skeletonize(
    ground_points, cell=grid_cell_m,
    max_points=point_budget, rng=rng,
)
```

The original defaults are preserved, including the `0.55` m pole grouping cell and `0.22` m pole slice step. These are component defaults, not a complete specification of every experiment configuration. `voxel_downsample` retains the first point per occupied voxel and randomly subsamples when the budget is exceeded. `ground_skeletonize` retains its original voxel fallback for oversized or empty skeleton grids and its random budget cap. Supply a seeded generator when deterministic sampling is needed.

## Data availability

The raw self-collected dataset is private laboratory data and cannot be publicly released. This repository contains no laboratory images, event streams, point clouds, calibration values, annotations, experiment outputs, credentials, or machine-specific data paths. Use your own authorized inputs with the component APIs above.
