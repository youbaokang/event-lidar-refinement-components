# 事件与激光雷达精修算法组件

本包公开事件结构目标、距离场和 LiDAR 骨架几何中的部分算法组件，共 13 个已有函数。函数体和默认参数按原代码保留，整理时仅配置必要导入和模块组织，便于脱离原实验室目录使用。

这是部分组件代码，未包含完整外参优化器、三轮标定运行程序、参考标定、实验驱动或论文结果复现脚本。

英文说明见 [README.md](README.md)。

## 包含内容

| 模块 | 函数 |
| --- | --- |
| `event_lidar_components/event_frontend.py` | 事件累积、密度过滤、活动图归一化、连通域过滤、方向感知掩膜，共 5 个函数 |
| `event_lidar_components/structure_geometry.py` | 距离场、相机中心、体素采样、杆体分组、杆体骨架，共 5 个函数 |
| `event_lidar_components/target_fields.py` | 二值骨架、细化目标、地面结构骨架，共 3 个函数 |

函数清单记录了保留函数的来源标识及哈希。依赖库源码没有打包。

## 安装与导入

使用 Python 3.10 或以上版本，依赖为 `requirements.txt` 中的 NumPy、OpenCV 和 SciPy。在包含本说明、`requirements.txt` 和 `event_lidar_components` 文件夹的仓库根目录运行。该目录下可以直接导入模块，无须执行 `pip install -e`。

Windows PowerShell：

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python your_program.py
```

Linux 或 macOS：

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python your_program.py
```

这些命令供使用者安装和调用。整理代码包时没有运行算法、补做实验或重新安装依赖环境。

## 输入要求

- 事件输入为等长的一维整数数组 `x`、`y`，使用从零开始的像素坐标，坐标必须位于给定图像宽、高范围内。调用者自行选择事件时间窗口并传入坐标。本包不含时间戳解析、极性规则、自动选窗及传感器同步程序。
- 二值掩膜为二维数组，正值代表目标结构，零代表背景。`orientation_aware_mask` 接收 `uint8` 灰度图，返回阈值二值图、竖向响应、横向响应及过滤后的合并响应四张 `uint8` 掩膜。
- 点集建议使用有限浮点数，形状为 `(N, 3)`，长度单位为米，`x`、`y` 为水平轴，`z` 为竖直轴。`split_poles_by_xy` 的输入是已从场景筛选的杆体候选点，不是完整原始点云分割入口。
- `camera_center(R, t)` 接收调用者提供的 `(3, 3)` 旋转和 `(3,)` 平移，变换约定为 `p_camera = R @ p_lidar + t`，返回 LiDAR 坐标系中的相机中心 `-R.T @ t`。

## 使用自己的数组

在仓库根目录新建 `your_program.py`，参考以下代码。`user_inputs.npz` 由使用者自行准备，本包不包含这个文件或任何其他数据集。

```python
import numpy as np

from event_lidar_components.event_frontend import (
    accumulate_events,
    density_filter,
    normalize_activity,
    orientation_aware_mask,
)
from event_lidar_components.structure_geometry import (
    make_dist_map,
    split_poles_by_xy,
    skeletonize_pole_group,
)
from event_lidar_components.target_fields import make_thin_target

with np.load("user_inputs.npz", allow_pickle=False) as data:
    width = int(data["width"].item())
    height = int(data["height"].item())
    x = np.asarray(data["x"], dtype=np.int64)
    y = np.asarray(data["y"], dtype=np.int64)
    pole_points = np.asarray(data["pole_points"], dtype=np.float64)

activity = accumulate_events(width, height, x, y)
gray = normalize_activity(density_filter(activity))
binary, vertical, horizontal, target = orientation_aware_mask(gray)
thin_target = make_thin_target(target)
mask_distance_px = make_dist_map(target)
thin_distance_px = make_dist_map(thin_target)

pole_groups = split_poles_by_xy(pole_points, cell_size=0.55)
pole_skeletons = [
    skeletonize_pole_group(group, step=0.22)
    for group in pole_groups
]
```

`mask_distance_px` 和 `thin_distance_px` 是像面距离场，不能直接作为外参旋转或平移误差。以上调用得到结构目标和骨架，不会输出标定外参。

## 其他调用与参数

`voxel_downsample(points, intensity, voxel, max_points, rng)` 返回采样点及对应强度；没有强度时传入 `None`。`ground_skeletonize(points, cell, max_points, rng)` 接收已分离的地面结构点。`rng` 应为使用者提供的 `numpy.random.Generator`；需要可重复采样时请自行指定种子。

原参数默认值保留，包括杆体分组网格 `0.55` m 和高度切片步长 `0.22` m。这些是组件默认值，不代表论文各项实验的全部配置。体素采样保留每个占据体素的首点，超出预算时随机抽样。地面骨架函数保留了过大网格、空骨架时的体素回退，以及超预算随机抽样行为。

## 数据声明

自采原始数据属于实验室私有数据，无法公开。本包不含实验室图像、事件流、点云、标定数值、标注、实验结果、账号凭据或本机数据路径。请使用自行获得授权的数据调用上述接口。
